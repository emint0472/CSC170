import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gator extends Actor
{
    /**
     * Act - do whatever the Gator wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(3);
        //Actor theGator = (Actor)getObjects(Pond.class).get(0); 
        
        if(isAtEdge()){
            //setRotation(getRotation() + 30);
            //turnTowards(theGator.getX(), theGator.getY());
            
        }    
        if(isTouching(Turtle.class)){
            removeTouching(Turtle.class);
        }
    }

}

