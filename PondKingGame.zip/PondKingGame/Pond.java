import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Pond here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pond extends World
{
    public static int score = 0;
    public static int level = 0;
   
    public static int yfCount = 0;
        
    /**
     * Constructor for objects of class Pond.
     * 
     */
    public Pond()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 700, 1); 
        prepare();
    }
    public void act()
    {
        showText("Score: " + score, 50, 25);
        showText("Level: " + level, 50, 50);
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    public void prepare()
    {
        Pond.score = 0;
        Turtle turtle = new Turtle();
        addObject(turtle, 600, 350);
        GreenFish greenFish = new GreenFish();
        addObject(greenFish,114,88);
        GreenFish greenFish2 = new GreenFish();
        addObject(greenFish2,405,574);
        GreenFish greenFish3 = new GreenFish();
        addObject(greenFish3,794,239);
        YellowFish yellowFish = new YellowFish();
        addObject(yellowFish,724,484);
        Island island = new Island();
        addObject(island,1054,109);
        Gator gator = new Gator();
        addObject(gator,112,658);
        Fly fly = new Fly();
        addObject(fly,1070,350);
    }
}
