import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Turtle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Turtle extends Actor
{
    static int speed = 3;
    static int flyTimer = 0;
    /**
     * Act - do whatever the Turtle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        checkDirection();
        checkCollision();
        
        if(flyTimer > 0){
            speed = 6;
            flyTimer--;
        }
        else{
            if(Pond.turtleAlive)
                speed = 3;
            else
                speed =0;
        }
        
    }   
    
    public void scoreFly(){
        removeTouching(Fly.class);
        flyTimer = 180;
    }
    
    public void processFish(String fishType){
        if(fishType.equals("Yellow")){
            removeTouching(YellowFish.class);
            Greenfoot.playSound("eatit.wav");
            Pond.score += YellowFish.points;
            Pond.yfCount--;
        }
        else{
            removeTouching(GreenFish.class);
            Greenfoot.playSound("eatit.wav");
            Pond.score += GreenFish.points;
            Pond.gfCount--;
        }
    }
    
    public void checkCollision(){
        if(isTouching(GreenFish.class)){
            processFish("Green");
        }
        if(isTouching(YellowFish.class)){
            processFish("Yellow");
        }
        if(isTouching(Gator.class)){
            
            Greenfoot.playSound("buzzer_x.wav");
            Pond.turtleAlive = false;
        }
        if(isTouching(Fly.class)){
            scoreFly();
            
        }
    }
    
    public void checkDirection(){
        if(Greenfoot.isKeyDown("s")||Greenfoot.isKeyDown("down")){
            setRotation(90);
            move(speed);
        }
        if(Greenfoot.isKeyDown("w")||Greenfoot.isKeyDown("up")){
            setRotation(-90);
            move(speed);
        }
        if(Greenfoot.isKeyDown("a")||Greenfoot.isKeyDown("left")){
            setRotation(180);
            move(speed);
        }    
        if(Greenfoot.isKeyDown("d")||Greenfoot.isKeyDown("right")){
            setRotation(0);
            move(speed);
        }   
    }
    
}

