import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class YellowFish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class YellowFish extends Actor
{
    static int speed = 2;
    public static int points = 4;
    static boolean isAware = false;
    
    /**
     * Act - do whatever the YellowFish wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(speed);
        checkEdge();    
        checkCollision();
        setDirection();
    
    }
    public void checkEdge(){
        if(isAtEdge()){
            turn(10);
        }
    }
    
    public void checkCollision(){
        if(isTouching(Island.class)){
            turn(Greenfoot.getRandomNumber(180));
        }
        if(isTouching(Beach.class)){
            setLocation(getX() - 10,getY());
            turn(Greenfoot.getRandomNumber(90));
        }
    }
    
    public void setDirection(){
        if(Pond.level > 5){
            isAware = true;
        }
        if(isAware && Pond.turtleAlive){
            turnTowards(Pond.turtle.getX(), Pond.turtle.getY());
            turn(180);
        }
    }
}