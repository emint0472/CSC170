import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Gator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Gator extends Actor
{
    static int speed = 3;
    static boolean isAware = false;
    /**
     * Act - do whatever the Gator wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        
        move(speed);
        checkEdge();
        setDirection();
        checkCollision();
        
    }
    public void checkEdge(){
        if(isAtEdge()){
            turn(70);
        }    
    }
    
    public void setDirection(){
        if(isAware && Pond.turtleAlive){
            turnTowards(Pond.turtle.getX(), Pond.turtle.getY());
        }
    }
    
    public void checkCollision(){
        if(isTouching(Island.class)){
            turn(Greenfoot.getRandomNumber(180));
        }
    }
}

