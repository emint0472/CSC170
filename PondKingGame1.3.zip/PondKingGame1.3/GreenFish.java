import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GreenFish here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GreenFish extends Actor
{
    static int speed = 1;
    static int points = 2;
    
    /**
     * Act - do whatever the GreenFish wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(speed);
        checkEdge();
        checkCollision();
    }
    
    public void checkEdge(){
        if(isAtEdge()){
            int turnAmount = Greenfoot.getRandomNumber(180);
            turn(turnAmount);
            
        }
    }
    
    public void checkCollision(){
        if(isTouching(Island.class)){
            turn(Greenfoot.getRandomNumber(180));
        }
        if(isTouching(Beach.class)){
            turn(Greenfoot.getRandomNumber(90));
        }
    }
}