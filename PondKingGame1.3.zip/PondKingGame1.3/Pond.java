import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Pond here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pond extends World
{
    public static int score = 1;
    public static int level = 1;
    public static boolean turtleAlive = true;
    public static Actor turtle; 
    public static int yfCount = 0;
    public static int gfCount = 0;
    public static int highScore = 0;
    
    /**
     * Constructor for objects of class Pond.
     * 
     */
    public Pond()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 700, 1); 
        prepare();
    }
    public void act()
    {
        showText("Score: " + score, 90, 25);
        showText("Level: " + level, 91, 50);
        
        
        if(gfCount == 0 && yfCount == 0){
            prepareLevel();
            level++;
        }
         if(!turtleAlive){
            
            //game over
            removeObjects(getObjects(Turtle.class));
            showText("GAME OVER", 550, 340);
            showText("Your Score: " + score, 550, 380);
            showText("High Score: " + highScore, 550, 420);
            if(score > highScore){
                highScore = score;
                showText("Congratulations! New High Score!", 550, 460);
            }
            
            Gator.speed = 0;
            GreenFish.speed = 0;
            YellowFish.speed = 0;
            Turtle.flyTimer = 0;
            Turtle.speed = 0;
            
        }
    }
    public void prepare(){
        Pond.score = 0;
        Pond.level = 1;
        Gator.isAware = false;        
        Beach beach = new Beach();
        addObject(beach,1130,20);
        GreenfootImage image = beach.getImage();
        image.scale(220, 220);
        turtle = new Turtle();
        addObject(turtle, 600, 350);
        Gator gator = new Gator();
        addObject(gator,1130,20);
        prepareLevel();
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    public void prepareLevel()
    {
        
        
        GreenFish.speed = 1;
        YellowFish.speed = 2;
        Gator.speed = 1;
        turtleAlive = true;
        Turtle.speed = 3;
        
        makeIsle();
        makeGreen();
        makeYellow();
        
        if(level % 8 == 0){
            Gator.speed++ ;
        }
        
        if(level > 1){
            Gator.isAware = true;
            removeObjects(getObjects(Gator.class));
            Gator gator = new Gator();
            addObject(gator,1130,20);
        }
        
        if(level % 6 == 0){
            Gator gator = new Gator();
            addObject(gator,1130,20);
        }
        
        Fly fly = new Fly();
        addObject(fly,15 ,Greenfoot.getRandomNumber(600) + 50);
    }
    
    public void makeIsle(){
        removeObjects(getObjects(Island.class));
        int intLevel = (int)(Pond.level / 2) + 1;
        
        int islandAmount = Greenfoot.getRandomNumber(intLevel) + 1;
        Island[] isles = new Island[islandAmount];
        for(int i = 0; i < isles.length; i++){
            isles[i] = new Island();
            addObject(isles[i],Greenfoot.getRandomNumber(900) + 100,Greenfoot.getRandomNumber(600) + 80);
            GreenfootImage image = isles[i].getImage();
            image.scale(Greenfoot.getRandomNumber(100) + 50, Greenfoot.getRandomNumber(100) + 50);
        }
    }
    
    public void makeGreen(){
        gfCount = 2 + Greenfoot.getRandomNumber(level);
        GreenFish[] gf = new GreenFish[gfCount];
        for(int i = 0; i < gf.length; i++){
            gf[i] = new GreenFish();
            gf[i].turn(180 + Greenfoot.getRandomNumber(170));
            addObject(gf[i],Greenfoot.getRandomNumber(1000),Greenfoot.getRandomNumber(650));
        }
    }
    
    public void makeYellow(){
        yfCount = 1 + Greenfoot.getRandomNumber(2);
        YellowFish[] yf = new YellowFish[yfCount];
        for(int i = 0; i < yf.length; i++){
            yf[i] = new YellowFish();
            yf[i].turn(180 + Greenfoot.getRandomNumber(170)); 
            addObject(yf[i],Greenfoot.getRandomNumber(1000),Greenfoot.getRandomNumber(650));
        }
    }
}
