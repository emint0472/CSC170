import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Turtle here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Turtle extends Actor
{
    /**
     * Act - do whatever the Turtle wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
          if(Greenfoot.isKeyDown("s")||Greenfoot.isKeyDown("down")){
            setRotation(90);
            move(3);
        }
        if(Greenfoot.isKeyDown("w")||Greenfoot.isKeyDown("up")){
            setRotation(-90);
            move(3);
        }
        if(Greenfoot.isKeyDown("a")||Greenfoot.isKeyDown("left")){
            setRotation(180);
            move(3);
        }    
        if(Greenfoot.isKeyDown("d")||Greenfoot.isKeyDown("right")){
            setRotation(0);
            move(3);
        }    
              
        if(isTouching(GreenFish.class)){
            removeTouching(GreenFish.class);
            Greenfoot.playSound("eatit.wav");
            Pond.score += GreenFish.points;
            GreenFish.greenCount--;
        }
        if(isTouching(YellowFish.class)){
            removeTouching(YellowFish.class);
            Greenfoot.playSound("eatit.wav");
            Pond.score += YellowFish.points;
        }
    }   

}

